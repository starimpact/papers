These files are supplemental materials for the following submission

H. Li et al., "Object Matching Using A Locally Affine Invariant and  Linear Programming Techniques", submitted to TPAMI.

Please use MATLAB to run house_matching_demo.m and hotel_matching_demo.m to show the demos. The CVX library is required and can be downloaded at http://cvxr.com/cvx/.
