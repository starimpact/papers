%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% H. Li et al., "Object Matching Using A Locally Affine Invariant and 
% Linear Programming Techniques", submitted to TPAMI.
%
% This demo demonstrates the matching between the frame 1 and frame 91 of 
% the CMU Hotel sequence. It is not written for general matching cases.
% 
% It requires the CVX library (http://cvxr.com/cvx/)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all;
clear;
clc;

load hotel_demo.mat;

% Display template image and points
figure(1);
imshow( I_template );
hold on;
scatter( templatePts(:,1), templatePts(:,2), 200, 'y.' );
hold on;
for j = 1 : size( templatePts, 1 )
    text( templatePts(j,1)-10, templatePts(j,2)-10, num2str(j), 'Color', [1 1 0] );
end
hold off;
axis on;
title('Template: Frame 1');

numTgtPts = size( templatePts, 1 );
numSrcPts = size( scenePts, 1 );

% Calculate the Shape Context features for template and scene point sets
[templateBH, mean_dist] = ...
        sc_compute( templatePts', zeros(1,numTgtPts), [], ...
        12, 5, 1/8, 2, zeros(1,numTgtPts) );
sceneBH = ...
        sc_compute( scenePts', zeros(1,numSrcPts), [], ...
        12, 5, 1/8, 2, zeros(1,numSrcPts) );
C = hist_cost_2( templateBH, sceneBH );

NE = getNeighborE( templatePts, 5 );

% Perform the matching
figure(2);
X = convexMatching121( templatePts, NE, scenePts, C, 0.05, [100 90 80 60 30 10], I_scene );

% Display the final results
transPts = X * scenePts;
figure(2);
imshow( I_scene );
hold on;
scatter( transPts(:,1), transPts(:,2), 600, 'y.' );
for j = 1 : size( transPts, 1 )
    text( transPts(j,1)-10, transPts(j,2)-10, num2str(j), 'Color', [1 1 0] );
end

scatter( scenePts(:,1), scenePts(:,2), 200, 'g.' );
for j = 1 : size( scenePts, 1 )
    text( scenePts(j,1)+6, scenePts(j,2)-10, num2str(j), 'Color', [0 1 0] );
end    
hold off;
axis on;
title('Scene: Frame 91');