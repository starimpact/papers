function E = getNeighborE( pts, N )

ptNum = size( pts, 1 );
E = zeros( ptNum, ptNum );

for i = 1:ptNum
     x = pts( i, 1 );
     y = pts( i, 2 );
     
     dist = ( x - pts(:,1) ).^2 + ( y - pts(:,2) ).^2 ;
     [sortedDist, distInd] = sort( dist );
     
     E( i, distInd( 2:N+1 ) ) = 1;
end
E = sparse(E);