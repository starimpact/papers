function X = convexMatching121( M, E, T, C, lambda, diameters, I_scene )

[Nm, dm] = size(M);
[Nt, dt] = size(T);

if Nm ~= Nt
    error('M and T must have the same number of points!');
end

if dm ~= dt || dt ~= 2
    error('DM and DT must be 2D points!');
end

if size( C, 1 ) ~= Nm || size( C, 2 ) ~= Nt
    error('C must have the size of Nm X Nt!'); 
end

% Calculate the 
H = getH( M, E );

cvx_solver sdpt3; 
cvx_begin
    variable X(Nm,Nt);
    minimize trace(C' * X) + lambda * norm( H * X * T, 1 );
    subject to
        X >= 0;
        X * ones( Nt, 1 ) == ones( Nm, 1 );
        ones( 1, Nm ) * X <=  ones( 1, Nt );
cvx_end

candidates = zeros( Nm, Nt );
for k = 1 : length( diameters )
    transM = X * T;
    
    if nargin >= 7
        imshow( I_scene );
        hold on;
        scatter( transM(:,1), transM(:,2), 600, 'y.' );
        for j = 1 : size( transM, 1 )
            text( transM(j,1)-10, transM(j,2)-10, num2str(j), 'Color', [1 1 0] );
%             drawCircle( transM(j,:), diameters(k), [1 1 0] )
        end
        
        scatter( T(:,1), T(:,2), 200, 'g.' );
        for j = 1 : size( T, 1 )
            text( T(j,1)+6, T(j,2)-10, num2str(j), 'Color', [0 1 0] );
        end
        
        hold off;
        axis on;
        pause(0.1);
    end
    
    for i = 1 : Nm
        allDist = repmat( transM(i,:), Nt, 1 ) - T;
        allDist = sqrt( allDist(:,1).^2 + allDist(:,2).^2 );
        candidatesI = allDist < diameters(k);
        if sum( candidatesI ) == 0
            continue;
        else
            candidates(i,:) = candidatesI;
        end
    end
    
    numVar = sum( candidates(:) );
    cvx_solver sdpt3;
    cvx_begin
        variable XX( numVar );
        expression X( Nm, Nt );

        varInd = 1;
        for i = 1 : Nm
            for j = 1 : Nt
                if candidates(i,j) ~= 0
                    X( i, j ) = XX( varInd );
                    varInd = varInd + 1;
                else
                    X( i, j ) = 0;
                end

            end
        end

        minimize trace(C' * X) + lambda * norm( H * X * T, 1 );
        subject to
            XX >= 0;
            X * ones( Nt, 1 ) == ones( Nm, 1 );
            ones( 1, Nm ) * X <= ones( 1, Nt );
     cvx_end
end

transM = X * T;
for i = 1 : Nm
    allDist = repmat( transM(i,:), Nt, 1 ) - T;
    allDist = sqrt( allDist(:,1).^2 + allDist(:,2).^2 );
    
    distC = allDist ;%,:)';
    
    [v, ind] = min( distC );
    X( i, : ) = 0;
    X( i, ind ) = 1;
end

% Calculate the reconstruction weights for template points
function H = getH( pts, E )
[Nm, d] = size( pts );

neighborhood = cell( Nm, 1 );
for i = 1:Nm
    neighborhood{i} = find( E(i,:) ~= 0 );
end

% Calculate the convex combination
% H = I - W
H = zeros(Nm, Nm);

for i = 1:Nm
     fprintf( 1, 'The %dth point.', i );
    
     % current point
     m = pts(i,:);
     % all neighbors
     n = pts( neighborhood{i}, : );
     % number of three neighbors
     nNum = length( neighborhood{i} );
     
     % set up sum(w) = 1
     A = ones( d+1, nNum );
     % set up d rows to be points
     A( 2:end, : ) = n';
     
     % set up sum(w) = 1
     b = ones( d+1, 1 );
     % set up recovered points
     b( 2:end ) = m;
     
     w = lsqr( A, b, 1e-12, 10 );
     
     H( i, neighborhood{i} ) = -w;
     H(i,i) = 1;
end
H = sparse(H);