MATLAB code and demo for the feature point-set matching method in


	H. Li, E. Kim, X. Huang, and L. He, "Object Matching with 
	A Locally Affine-Invariant Constraint", CVPR 2010


The code needs lpsolve 5.5 MATLAB version be installed.
How to setup lpsolve's MATLAB version can be found at http://web.mit.edu/lpsolve/doc/MATLAB.htm
lpsolve MATLAB version can be downloaded from http://sourceforge.net/projects/lpsolve/files/lpsolve/5.5.0.15/

The method can be performed by calling Convex_Matching_Affine.m. The arguments of the function are described in .m files.

example.m is a matlab demo for Convex_Matching_Affine.m. Run example.m in MATLAB, one matching demo will show.


*************************************************************************
Details on installation of lpsolve MATLAB version for Windows.
Installation on other OS is similar.
 
1. Download         lp_solve_5.5.0.15_dev_winxx.zip
from http://sourceforge.net/projects/lpsolve/files/lpsolve/5.5.0.15/.
xx specifies OS is 32 or 64 bit.
 
2. Unzip the .zip file, and put lpsolve55.dll into your system folder,
e.g., C:\WINDOWS\System32.
 
3. Download         lp_solve_5.5.0.15_MATLAB_exe_winxx.zip
from http://sourceforge.net/projects/lpsolve/files/lpsolve/5.5.0.15/.
xx specifies OS is 32 or 64 bit.
 
4. Unzip the .zip file, you will get a folder consisting of mxlpsolve.m.
Add this folder and all its subfolders' path into your MATLAB 
path (File->Set Path...->Add with Subfolders).

 
5. type "mxlpsolve" and Enter in MATLAB command window. If your lpsolve
is correctly installed. It will show:
mxlpsolve  MATLAB Interface version 5.5.0.6
using lpsolve version 5.5.0.15
 
Usage: ret = mxlpsolve('functionname', arg1, arg2, ...)
 
6. If something else show up, troubleshoot the problem by reading
http://web.mit.edu/lpsolve/doc/MATLAB.htm.
*************************************************************************



Copyright (c) Hongsheng Li @ Lehigh Univeristy
Feel free to contact me through	 h.li at lehigh.edu