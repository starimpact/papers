function newTrustRegion = Update_TrustRegion( anchorPoints, trustRegion, diameterSpeed )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function upadates each model point's trust region 
%
% It should be called by Convex_Matching_Affine.m 
% 
% INPUT
% anchorPoints          An Nm x 2 matrix. The ith row records ith model's
%                       trust region center
% trustRegion           An Nm x 4 trust region matrix. The ith row records ith
%                       model point's trust region. Each row has a data
%                       structure like [x_min x_max y_min y_max]
% diameterSpeed         Trust region dismeter decreasing speed parameter
%
% OUTPUT
% newTrustRegion        An Nm x 4 trust region matrix. The ith row records ith
%                       model point's new trust region. Each row has a data
%                       structure like [x_min x_max y_min y_max]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Nm = size( anchorPoints, 1 );
newTrustRegion = zeros( size(trustRegion) );

for i = 1:Nm
    x = anchorPoints( i, 1 );
    y = anchorPoints( i, 2 );
    
    xmin = trustRegion( i, 1 );
    xmax = trustRegion( i, 2 );
    ymin = trustRegion( i, 3 );
    ymax = trustRegion( i, 4 );

    diffXmin = abs( x - xmin );
    diffXmax = abs( xmax - x );
        
    diffYmin = abs( y - ymin );
    diffYmax = abs( ymax - y );
    
    % X
    % 1) overall shrinkable
    % 1.1 both direction can shrink
    % 1.2 xmin get boundary, xmax can shrink more
    % 1.3 xmax get boundary, xmin can shrink more
    % 2) not able to shrink, do nothing
    if diffXmin + diffXmax > 2 * diameterSpeed
        % 1.1
        if diffXmin > diameterSpeed && diffXmax > diameterSpeed
            xmax = xmax - diameterSpeed;
            xmin = xmin + diameterSpeed;
        end
        % 1.2
        if diffXmin < diameterSpeed
            xmin = x + eps;
            xmax = xmax - (2 * diameterSpeed - diffXmin);
        end
        % 1.3
        if diffXmax < diameterSpeed
            xmax = x - eps;
            xmin = xmin + (2 * diameterSpeed - diffXmax);
        end
    end
    
    % Y
    % 1) overall shrinkable
    % 1.1 both direction can shrink
    % 1.2 ymin get boundary, ymax can shrink more
    % 1.3 ymax get boundary, ymin can shrink more
    % 2) not able to shrink, do nothing
    if diffYmin + diffYmax > 2 * diameterSpeed
        % 1.1
        if diffYmin > diameterSpeed && diffYmax > diameterSpeed
            ymax = ymax - diameterSpeed;
            ymin = ymin + diameterSpeed;
        end
        % 1.2
        if diffYmin < diameterSpeed
            ymin = y + eps;
            ymax = ymax - (2 * diameterSpeed - diffYmin);
        end
        % 1.3
        if diffYmax < diameterSpeed
            ymax = y - eps;
            ymin = ymin + (2 * diameterSpeed - diffYmax);
        end
    end
    
    newTrustRegion( i, 1 ) = xmin;
    newTrustRegion( i, 2 ) = xmax;
    newTrustRegion( i, 3 ) = ymin;
    newTrustRegion( i, 4 ) = ymax;
end

% diameter = diameter - diameterSpeed;