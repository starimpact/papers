function trustRegion = Set_TrustRegion( anchorPoints, diameter )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This function sets initial trust regions for each model points. 

% It should be called by Convex_Matching_Affine.m
% 
% INPUT
% anchorPoints          An Nm x 2 matrix. The ith row records ith model's
%                       trust region center
% diameter              The initial trust region diameter
% 
% OUTPUT
% trustRegion           Nm x 4 trust region matrix. The ith row records ith
%                       model point's trust region. Each row has a data
%                       structure like [x_min x_max y_min y_max]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Nm = size( anchorPoints, 1 );

trustRegion = size(Nm, 4);

for i = 1:Nm
    x = anchorPoints( i, 1 );
    y = anchorPoints( i, 2 );
    
    xmin = x - diameter;
    xmax = x + diameter;
    ymin = y - diameter;
    ymax = y + diameter;
    
    trustRegion( i, 1 ) = xmin;
    trustRegion( i, 2 ) = xmax;
    trustRegion( i, 3 ) = ymin;
    trustRegion( i, 4 ) = ymax;
end