function X = Convex_Matching_Affine( M, E, T, C, lambda, ...
    roundingIterNum, diameterParams, Nsame )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function matches two feature point-sets using the method in
% H. Li, E. Kim, X. Huang, and L. He, "Object Matching Using a Locally 
% Affine-invairant Constraint", CVPR 2010. Please cite this paper if you
% used this program.
%
% INPUT
% M                 An Nm x 2 matrix. The ith row represents the ith 2D
%                   model point.
% E                 An N x N 0-1 edge matrix. The ith row records the ith 
%                   point's neighbors
% T                 An Nt x 2 matrix recording 2D Nt target points' coordinates.
% C                 The Nm x Nt feature matching cost matrix.
% lambda            The parameter weighting feature cost and geometric
%                   cost.
% roundingIterNum   The function will use the the "consitent-rounding" for 
%                   the last roundingIterNum iterations. consitent-rounding
%                   is described in Seciont II.B of [10] Jiang et al. TPAMI 2007.
% diameterParams    should be either [maxDiameter minDiameter diameterSpeed]
%                   or [maxDiameter minDiameter diameterSpeed finalDiameter]
%                   maxDiameter is the maximum diameter of trust regions.
%                   minDiameter is the minimum diameter of trust regions.
%                   diameterSpeed is the diameter decreasing speed.
%                   finalDiameter is the final diameter for non-simplified
%                   LP model.
% Nsame             A parameter tuning the "matching to the same target point" 
%                   constraint. For each target point, no more than Nsame model
%                   points can be matched to it.
%
%
% All matlab functions required by this function include:
%
% LP_Matching.m
% Set_TrustRegion.m
% Get_Reconstruction_Coeff.m
% Update_TrustRegion.m
% Find_Anchors.m
% Is_TrustRegion_Empty.m
% lpsolve 5.5 matlab version 
%
% The function needs lpsolve 5.5 MATLAB version be installed.
% How to setup lpsolve's MATLAB version can be found at 
% http://web.mit.edu/lpsolve/doc/MATLAB.htm
%
% lpsolve MATLAB version can be downloaded from 
% http://sourceforge.net/projects/lpsolve/files/lpsolve/5.5.0.15/
%
% *************************************************************************
% Details on installation of lpsolve MATLAB version for Windows.
% Installation on other OS is similar.
% 
% 1. Download         lp_solve_5.5.0.15_dev_winxx.zip
% from http://sourceforge.net/projects/lpsolve/files/lpsolve/5.5.0.15/.
% xx specifies OS is 32 or 64 bit.
% 
% 2. Unzip the .zip file, and put lpsolve55.dll into your system folder,
% e.g., C:\WINDOWS\System32.
% 
% 3. Download         lp_solve_5.5.0.15_MATLAB_exe_winxx.zip
% from http://sourceforge.net/projects/lpsolve/files/lpsolve/5.5.0.15/.
% xx specifies OS is 32 or 64 bit.
% 
% 4. Unzip the .zip file, you will get a folder consisting of mxlpsolve.m.
% Add this folder and all its subfolders' path into your MATLAB path 
% (File->Set Path...->Add with Subfolders).
% 
% 5. type "mxlpsolve" and Enter in MATLAB command window. If your lpsolve
% is correctly installed. It will show:
% mxlpsolve  MATLAB Interface version 5.5.0.6
% using lpsolve version 5.5.0.15
% 
% Usage: ret = mxlpsolve('functionname', arg1, arg2, ...)
% 
% 6. If something else show up, troubleshoot the problem by reading
% http://web.mit.edu/lpsolve/doc/MATLAB.htm
% *************************************************************************
%
% Copyright (c) Hongsheng Li @ Lehigh University
% Feel free to contact me through   h.li at lehigh.edu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if length(diameterParams) < 3
    error('diameterParams should be a length 3 or 4 vector!');
end

% Get diameter parameters
maxDiameter = diameterParams(1);
minDiameter = diameterParams(2);
diameterSpeed = diameterParams(3);

if maxDiameter < minDiameter
    error('maxDiameter should greater than minDiameter!');
end

if length(diameterParams) > 3
    finalDiameter = diameterParams(4);
else
    finalDiameter = minDiameter;
end

iterNum = floor( ( maxDiameter - minDiameter ) / diameterSpeed );
iterNumThres = iterNum - roundingIterNum;

if roundingIterNum > iterNum || roundingIterNum < 1
    error( 'roundingIterNum should be between 1 and iterNum!' );
end

[Nm, dm] = size(M);
[Nt, dt] = size(T);

if dm ~= dt || dt ~= 2
    error('M and T must be 2D points!');
end

if size( C, 1 ) ~= Nm || size( C, 2 ) ~= Nt
    error('C must have the size of Nm x Nt!'); 
end

if size( E, 1 ) ~= Nm || size( E, 2 ) ~= Nm
    error('E must have the size Nm x Nm!');
end

if Nsame < 1
    error('Nsame should not be smaller than 1!');
end

if lambda < 0
    error('lambda should not be smaller than 0!');
end

% Apply lambda to C
C = C ./ lambda;

% Calculate the reconstruction matrix
[H, MNeighborhood, MNeighborCoeff] = Get_Reconstruction_Coeff( M, E );

% allocation memory for all auxilary varaibles
% basis
basis = cell( Nm, 1 );
for i = 1:Nm
    basis{i} = 1:Nt; 
end

% find initial basis
for i = 1:Nm
    costSurf = [ T(basis{i},:) C(i, basis{i})'];
    costSurfHull = convhulln(costSurf, {'Qt' 'PD2'});
    costSurfHull = sort( costSurfHull(:) );
    ind = costSurfHull ~= [ costSurfHull(2:end); 0 ];
    basis{i} = costSurfHull(ind);
end

% construct LP0 and solve it
[X, obj] = LP_Matching( H, T, C, basis, Nsame );

fprintf(1, 'All possible points.\n');

% calculate anchor points using LP's result
anchorPoints = X * T;

% update trust regions
trustRegion = Set_TrustRegion( anchorPoints, maxDiameter );

for iter = 1:iterNum
    fprintf( 1, 'Current diameter: %f\n', maxDiameter - diameterSpeed * iter );
    beginTime = cputime;
    
    % for every point in the M, update trust region and update basis.
    for i = 1:Nm
        insideInd = [];
        
        for j =1:Nt
            x = T(j, 1);
            y = T(j, 2);
            
            if x >= trustRegion(i,1) && x <= trustRegion(i,2) ...
                    && y >= trustRegion(i,3) && y <= trustRegion(i,4)
                insideInd = [insideInd j];
            end
        end
        
        if length( insideInd ) < 4
            continue;
        end
        
        costSurf = [ T(insideInd,:) C(i, insideInd)'];
        costSurfHull = convhulln(costSurf, {'Qt' 'PD2'});
        costSurfHull = sort( costSurfHull(:) );
        ind = costSurfHull ~= [ costSurfHull(2:end); 0 ];
        basis{i} = insideInd( costSurfHull(ind) );
    end
    
    % construct LP and solve it
    [X, obj] = LP_Matching( H, T, C, basis, Nsame );
    
    if iter <= iterNumThres
        % calculate anchor points directly using LP's result
        anchorPoints = X * T;
    else
        [anchors, newIntObj] = ...
            Find_Anchors( X, H, MNeighborhood, MNeighborCoeff, T, C, trustRegion );
        
        for ptInd = 1:length( anchors )
            anchorPoints( ptInd, : ) = T( anchors( ptInd ), : );
        end
    end
    
    % update trust regions
    newTrustRegion = Update_TrustRegion( anchorPoints, trustRegion, diameterSpeed );
        
    emptyInd = Is_TrustRegion_Empty( newTrustRegion, T );
    trustRegion( ~emptyInd, : ) = newTrustRegion( ~emptyInd, : );
    
    endTime = cputime;
    fprintf( 1, 'This iteration runs for %fs\n', endTime - beginTime );
end

% The last iteration without convex trick
for i = 1 : Nm
     trustRegion = Set_TrustRegion( anchorPoints, finalDiameter );
     
     insideInd = [];
     for j =1 : Nt
         x = T(j, 1);
         y = T(j, 2);
            
         if x >= trustRegion(i,1) && x <= trustRegion(i,2) ...
                 && y >= trustRegion(i,3) && y <= trustRegion(i,4)
             insideInd = [insideInd j];
         end
     end
     
     basis{i} = insideInd;
end

% Resolve the un-simplified LP model
[X, obj] = LP_Matching( H, T, C, basis, Nsame );

[anchors, newIntObj] = ...
    Find_Anchors( X, H, MNeighborhood, MNeighborCoeff, T, C, trustRegion );

X = zeros( size(X) );
for i = 1:Nm
    X( i, anchors(i) ) = 1; 
end