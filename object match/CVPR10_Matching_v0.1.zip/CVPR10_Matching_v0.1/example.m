clear;
clc;
close all;

% Load demo data
load example.mat

% Display the model image and model graph
displayTemplate_forExmaple( I_model, modelPts, E );
title('Model');

% Display all feature points in the scene image
figure;
imshow( I_target );
hold on;
scatter( tgtPts(:,1), tgtPts(:,2), 'r.');
title('All feature points in the scene image');
axis on;
hold off;

% Match the two feature point-set
X = Convex_Matching_Affine(modelPts, E, tgtPts, C, lambda, roundingIterNum, diameterParams, Nsame);

% Display the matching results in the scene image
figure;
displayMatching_forExample( X, I_target, tgtPts, E );
title('Result')

% Display parameter settings
fprintf(1, '\n\nParameter seetings:\n');
fprintf(1, 'lambda = %d\n', lambda);
fprintf(1, 'Max diameter = %d\n', diameterParams(1) );
fprintf(1, 'Min diameter = %d\n', diameterParams(2) );
fprintf(1, 'Diameter decreasing speed = %d\n', diameterParams(3) );
fprintf(1, 'Final diameter = %d\n', diameterParams(4) );
fprintf(1, 'roundingIterNum = %d\n', roundingIterNum ); 
fprintf(1, 'Nsame = %d\n', Nsame );