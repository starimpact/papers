function [X, obj] = LP_Matching( H, T, C, basis, Nsame )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function models a linear programming (LP) model for matching and
% solves it.
% 
% This function should be called by Convex_Matching_Affine.m. It requires lpsolve
% 5.5 or later matlab version be installed. Guide for matlab version can be 
% found at http://web.mit.edu/lpsolve/doc/MATLAB.htm
% 
% INPUT
% H             The Nm x Nm reconstruction matrix of the template point set.
% T             An Nt x 2 matrix recording 2D Nt target points' coordinates.
% C             The Nm x Nt feature matching cost matrix.
% basis         An Nm x 1 cell vector. The ith element records ith model
%               point's candidate matching points in the target point-set.
% Nsame         A parameter tuning the "matching to the same target point" 
%               constraint. For each target point, no more than Nsame model
%               points can be matched to it.
%
% OUTPUT
% X             The 0-1 Nm x Nt matching result matrix. The ith row of X
%               records the ith model point's matching results. If X(i,j)
%               == 1, the ith model point is matched to the jth target
%               point.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~iscell(basis) || ~isvector( basis )
    error('BASIS must be cell vector'); 
end

if size(C, 2) ~= size(T, 1)
    error('Cost matrix C''s 2 dim does not fit T''s 1st dim!'); 
end

[Nm, Nt] = size(C);
d = size(T, 2);

basisNum = zeros( Nm, 1 );
for i = 1:length( basis )
    basisNum(i) = length( basis{i} );
end 

basisEnd = cumsum( basisNum );
basisStart = [1; basisEnd(1:end-1)+1];

% formulate matrix for the same point matching constraints
sameM = zeros( Nm, Nt );
sameInd = zeros( Nm, Nt );

sumInd = 0;
for i = 1:length( basis )
    sameM( i, basis{i} ) = 1;
    sameInd( i, basis{i} ) = sumInd + 1 : sumInd + length( basis{i} );
    
    sumInd = sumInd + length( basis{i} );
end

sameNum = sum( sum( sameM, 1 ) ~= 0 );
sameNumInd = find( sum( sameM, 1 ) ~= 0 );

% obj_fun
% first term
% baisis part
f1 = zeros( 1, basisEnd(end) );
for i = 1:Nm
    f1 (basisStart(i):basisEnd(i)) = C(i, basis{i}); 
end

% geometric part
f2 = ones( 1, Nm * d * 2 );

%obj_fn
f = [f1 f2];

% constraints A
% Nm, sum(X) = 1
% Nm X 2 absolute linearization
% sameNum, penalty of mapping multiple points to one point
xNum = length(f1);
varNum = length(f);
A = zeros( Nm * 3 + sameNum, varNum );
% A = sparse( Nm * 3 + sameNum, varNum );
% sum part
for i = 1:Nm
    A(i, basisStart(i):basisEnd(i)) = 1; %ones(1, basisNum(i)); 
end

% absolut linearization part
% for each row in H
for i = 1:Nm
    % row number
    % x
    d1 = Nm + i * 2 - 1;
    % y
    d2 = d1 + 1;
    
    % for each item in one row of H
    for j = 1:Nm
        T1 = T( basis{j}, 1 );
        T2 = T( basis{j}, 2 );
        
        yzInd1 = xNum + j * 4 - 3;
        yzInd2 = yzInd1 + 2;
        
        A( d1, basisStart(j):basisEnd(j) ) = H(i,j) * T1;
        A( d1, yzInd1:yzInd1+1 ) = [1 -1];
        
        A( d2, basisStart(j):basisEnd(j) ) = H(i,j) * T2;
        A( d2, yzInd2:yzInd2+1 ) = [1 -1];
    end
end

% mapping multiple points to one point
for i = 1:sameNum
     ind = sameInd( :, sameNumInd(i) );
     A( Nm * 3 + i, sameInd( ind ~= 0, sameNumInd(i) ) ) = 1;
end

% b
b = zeros( size(A, 1), 1 );
b( 1:Nm ) = 1;
b( Nm * 3 + 1 : end ) = Nsame;

% constraints relations
InEqs = zeros( size(A, 1), 1 );
InEqs( Nm * 3 + 1 : end ) = -1;

lp = lp_maker( f, A, b, InEqs, [], [], [], 1, 1);
solvestat = mxlpsolve('solve', lp);
obj = mxlpsolve('get_objective', lp);
compactX = mxlpsolve('get_variables', lp);
mxlpsolve('delete_lp', lp);

X = sparse( Nm, Nt );
for i = 1:Nm
     X(i, basis{i} ) = compactX( basisStart(i):basisEnd(i) );
end