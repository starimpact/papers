function fig = displayMatching( X, I, pts, E )

X = logical(X);
matchedPts = X * pts;

imshow(I);
hold on;

for i = 1:size(E,1)
    for j = 1:size(E,2)
        if E(i,j) ~= 0
            plot( [matchedPts( i, 1) matchedPts( j, 1 )], ...
                [matchedPts( i, 2 ) matchedPts( j, 2 )], 'c' ); 
        end
    end
end

fig = scatter( matchedPts(:,1), matchedPts(:,2), 'r.' );

axis on;
hold off;