function displayTemplate( I, pts, E )

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ARGUMENTS:
% I         input image
% pts       N X 2 points
% E         N X N  0-1 symmetric edge matrix
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Display image
imshow(I);
hold on;

% Display edges
for i = 1:size(E,1)
    for j = 1:size(E,2)
        if E(i,j) ~= 0
            plot( [pts( i, 1 ) pts( j, 1 )], ...
                [pts( i, 2 ) pts( j, 2 )], 'c' ); 
        end
    end
end

% Display nodes
scatter( pts(:,1), pts(:,2), 'r.' );
axis on;
hold off;